# ICP-Solitaire
Solitaire in C++
